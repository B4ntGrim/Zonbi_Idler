# CURRENT_BATCH — none active

**Status:** No active batch (Oct 10). FX1 and FX2 are CLOSED (`reference/archive/fx1-batch.md`, `reference/archive/fx2-batch.md`).
**Next in the fix train:** CB1 starter weapons (`reference/starter-weapons-cb1-slice.md`) — becomes this file only after Sam locks it. Then FX3, FX4, H2.
**Do not start any batch until this file names one.**
