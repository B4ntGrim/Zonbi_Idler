# CODE_STATE — current implementation facts

- Stress is stored as an exact integer number of units (1 unit = 1/5.184×10¹² of a point; key `zi_stress`, field `u`). The ×1.15 overload rate and one-off stress events round to this unit; there is no saved fractional remainder.
- Batch R1 (Retreat Rules) is wired in `game/active.js` (bottom section): `WanderSim._ruleCheck` runs at the top of every walking segment and at the end of each chunk; `_msToRule` makes the stress-rule threshold an exact boundary; `_holdStep` runs HOLD; `_restStep` ends rest only at HP ≥ 80% AND stress < 50 (both exact ms). `advance(state, dt, away, rng, events, { watching })` — default unwatched; `WanderEngine.liveStep` passes `ZI.retreatWatching()` (real screen element laid out + page visible). A chunk > `watchMaxLagMs` (2 s) is catch-up and never watching. A saved HOLD from another page load (`hold.session`) is converted to a withdrawal on the first advance. Rest location is `state.restAt` ('checkpoint' | 'base'); rate via `ZI.restStressPerDay(restAt)` → `restBed()`. Tests: `tests/r1.test.js`.
- Save schema: v7 (tutorial follow-up: `zi_tut_progress`, registered last in `game/active.js` as previous + 1). v6 (R1: `zi_retreat_rules`; run fields `retreatSnoozes`, `retreatHold`, `withdrawCauses`). v5 (Batch 3B). v5 adds a pickup sequence (`seq`) to Wandering haul entries and `pickupSeq` to the run; older entries get it from saved order starting at 0.
- Forced Retreat has one entry point: `ZI.forcedRetreat(state, cause, rng)` in `game/active.js` (causes: 'breaking', 'downed'). The old out-of-heals `WanderSim._retreat` and the 10% Breaking loss were removed.
- Tutorial-done flags (`zi_trav_tutorial_done`, `zi_wander_tut_done`, `zi_craft_tut_done`) are per save (tutorial spec 9.1/9.2): part of each slot snapshot, absent in a new save. Read with `ZI.tutDone(key)` ('1' or legacy 'true' = finished), write with `ZI.setTutDone(key)` ('1'). Each screen's "?" is `window.TutStepMenu` (step list → open any single step). Tests: `tests/tutorial-flags.test.js`.
- Tutorial step progress: `zi_tut_progress` (per save, JSON list of step ids; new save `[]`). Ids are permanent keys in `ZI.TUT_STEP_IDS` (game/save.js): traversal 4, wandering 7 (`wandering.<tut>`), crafting 3. API: `ZI.getTutProgress()`, `ZI.markTutSteps(ids)`, `ZI.tutStepsDone(ids)`. `setTutDone` writes the flag and the screen's ids; `tutDone` is true from the flag or from all of the screen's ids. v7 migration fills ids from the old flags (data only; flags kept). Adding a step id to a finished screen makes `tutDone` false for it unless the flag is set — decide per screen when the six tab tutorials/revisions land.
- Every "?" (`TutStepMenu`) is bottom-right (Traversal inset 14, Wandering/Crafting 12). A new file opens on Traversal via `zi_fresh_start` (game/save.js → app `screen` init). Stats: SURVIVAL Attributes, Weather and Zombie Index panels show `<PreviewTag/>` (screens-v2.jsx).
- Test runner note: suites expect `readFile`/`log`; `tests/qa-helper.js` `fp()` hashes keys in storage order, so it can change when only key order changes — compare a sorted-key fingerprint too.

## H1 audit — clock and rolls (sim harness brief A1, A2; step-0 line numbers)

Clock rule (A1): every rule and every deterministic record reads `ZI.now()`. Real time stays only for session ids, `savedAt`, the reload-resume window and simulation locking.

| File:line (step 0) | Function | Purpose | Clock | Reason |
|---|---|---|---|---|
| jobs.js:44 | `ZI.now` | the clock itself | moves to core.js | core loads first; jobs no longer defines it |
| wandering.js:14, 27 | `getCmdWindow`, `cmdResetInMs` | 24 h command window | ZI.now | rule |
| wandering.js:142, 150 | `policyCooldownLeftMs`, `setPolicy` | policy-switch cooldown | ZI.now | rule |
| wandering.js:254 | `WanderEngine.start` interval | decay housekeeping | ZI.now | rule (decay) |
| wandering.js:259, 262 | `tick`, `liveStep` default `now` | elapsed time (dt) | ZI.now | rule |
| wandering.js:266-272 | `WanderEngine._lead` | simulation lock | **real time** | A1 exemption (simulation locking) |
| wandering.js:267 | `_lead` session fallback | session id | **real time** | A1 exemption (session id) |
| wandering.js:315 | `step` buffs | `combatBuffsAt(_simNow)` | simulated (`_simNow`) | unchanged; the fallback `Date.now()` is unreachable once `_simNow` is seeded |
| wandering.js:372 | `advance` | `_simNow` re-anchor to wall clock | **removed** | A1a: advance() reads no clock |
| stats.js:293, 296 | `skillDecayState`, `skillIdleDays` | decay stamps, idle days | ZI.now | rule |
| stats.js:315, 339, 365 | `getDecayClock`, `settleSkillDecay`, `_maybeSettleOnRead` | decay clock | ZI.now | rule |
| stats.js:369, 370 | `getInjury`, `setInjury` | injury expiry | ZI.now | rule |
| items.js:322 | `getActiveBuffs` | buff expiry (evade, XP) | ZI.now | rule; G1 (two buff clocks) not fixed |
| items.js:333 | `addBuff` | buff from/until | ZI.now | rule |
| items.js:630 | `reportCarryRefusal` | UI message stamp | real time (unchanged) | not read by a rule or a deterministic record |
| factions.js:172 | `repApply` | last-offense stamp | ZI.now | rule (forgiveness reads it) |
| factions.js:178 | `settleRepForgiveness` | forgiveness elapsed time | ZI.now | rule; G3 (1 day per settle) not fixed |
| economy.js:29 | `toRecyclerItem` | Recycler entry id | ZI.now + roll hook `'ids'` | deterministic record |
| economy.js:36 | `toRecyclerItem` | `bankedAt` (sort) | ZI.now | deterministic record |
| routes.js:94 | `tryDiscoverVehicle` | vehicle found-at stamp | ZI.now | deterministic record |
| bootstrap.js:69 | load-time decay wrapper | decay `lastActiveUtc` | ZI.now | rule |
| save.js:154 | `_boot` | decay-clock creation | ZI.now | rule |
| save.js:72, 93 | `_writeSlot` etc. | `savedAt` | **real time** | A1 exemption |
| save.js:99, 138 | resume | reload-resume window | **real time** | A1 exemption |
| active.js:599 | `ZI._session` | session id | **real time** | A1 exemption |

Out of scope, unchanged (D3): core.js world clock (34-49; no in-scope rule reads it), camp.js, jobs.js job ids, routes.js 162-269, fort.js, factions.js:98 (contracts).

**Rolls (A2, A3).** The Wandering simulation already receives one injectable `rng` (WanderEngine.rng; live `null` → `Math.random`; tests `ZI.seededRng(seed)`), passed through `advance` → `step`, combat, the evade roll and vehicle discovery. It is unchanged. The only in-scope `Math.random()` outside it is the Recycler id (economy.js:29), which goes through `ZI.roll('ids')`. `rng || Math.random` fallbacks in combat.js:27, stats.js:273, wandering.js:106, 199, active.js:117, 666, 772 and routes.js:91 stay as they are (only reached when no rng is passed). Session ids keep `Math.random` (exemption). Out of scope: world.js:112, fort.js:142, 151, routes.js:231-238, camp.js, jobs.js:80.

**C1-C13 (feasibility review, Oct 9), carried over.** C3: rules run headless with an in-memory storage shim; the only DOM read is `retreatWatching()` (active.js:609). C5: `DIFFICULTY_TABLE` has only `normal: { fortAttackHp }`; no in-scope system reads difficulty. C8: 24 h cap at wandering.js:281 (`WanderEngine._run`), not in `advance()`. C9: `advance()` stops after 200 steps or the 100,000 guard; the remainder is saved in `_carryMs` and resumed by the next call. C10: no permanent run end; HP floors at 1; Downed and Breaking go through `ZI.forcedRetreat`. C11: only r1 checks 20 and 26 (x2) depend on the exact seeded sequence. C13: see the watching list (step 8).

## H1 implementation facts (Oct 9)

**Clock.** `ZI.clockNow()` (game/core.js) is the one gameplay and deterministic-record clock: real time unless a clock is installed with `ZI.installClock(fn)`, or provided before load as `ZI._installedClock` (a harness does this so load-time settles use simulated time too). `ZI.now()` (game/jobs.js) returns the same clock. Rule code calls `ZI.clockNow()` because the load-time replay in game/bootstrap.js hides `ZI.now` before old line 1650, as the legacy file never defined it earlier. `ZI.now` is **not** in the replay's `ALWAYS` list and stays hidden, to keep the replay faithful to legacy load order. `ZI.clockNow()` is never hidden, so rule code works at every load stage. (Corrected Oct 10, TQ7: adding `now` to `ALWAYS` was tested in isolation and changes no current result; an earlier note claiming 16 changed results was wrong. Those failures came from a name collision with the world clock's `ZI._clock`.)
**Rolls.** `ZI.roll(system)` (game/core.js): live = `Math.random()`; `ZI.installRolls(masterSeed)` gives each system its own `ZI.seededRng` stream (seed = masterSeed XOR FNV-1a(system)). Used by: `toRecyclerItem` id (`'ids'`). The Wandering `rng` is unchanged.
**`_simNow` contract.** `WanderEngine._run` seeds `_simNow = now − (window + carried time)`: the previous `lastTickAt` in every uncapped case; after a capped absence the window ends at now, as before. `advance()` reads no clock and moves `_simNow` by every consumed millisecond, including rest (`_restStep`, the legacy rest branch) and HOLD. If `_simNow` is missing it starts from `lastTickAt` (or 0). The 2 s re-anchor is gone.
**Real time kept (A1 exemptions):** simulation lock (`WanderEngine._lead`, `realNow`), session ids, `savedAt`, the reload-resume window, and the UI stamp in `reportCarryRefusal`.

### Verified bounds (D7)
| Value | Rule | Bound |
|---|---|---|
| Skill level | `statLevel` stops at 50 (stats.js) | 1–50 |
| Skill XP | `addStatXp` adds only positive amounts; decay sets `floor + above × (1 − rate × days)` (stats.js `settleSkillDecay`) | **finite only**: no rule stops XP going below the floor or 0 when `rate × days > 1` (listed for Sam) |
| Base charges | spent only while > 0; refill sets `baseChargeMax()` (active.js `spendCharge`, `refillBaseCharges`) | 0–`baseChargeMax` |
| Kit charges | spent from > 0; an empty kit is removed (active.js `spendCharge`) | 1–`kitFull` while the kit exists |
| Durability | `applyWear` and `itemDurability` clamp (items.js) | 0–max |
| HP | most paths floor at 1, but base rest after a Downed forced retreat starts from `restStartHp = 0` | **0–100** (observed 0.0999; pre-existing; Design Handoff) |
| Stress | `_setStressU` clamps integer units (active.js) | 0–max × `STRESS_UNITS` |

### Watching list (A4) — behavior that differs when watching or when the Wandering screen is open
| Where | Behavior |
|---|---|
| active.js `WS._ruleCheck` | watching: a retreat rule opens the HOLD prompt; unwatched: withdraws at once |
| active.js `WS._holdStep` | not watching (or a HOLD from another session): HOLD is cancelled into a withdrawal |
| wandering.js `advance` | watching only when the chunk is ≤ `watchMaxLagMs` (2 s); bigger chunks are catch-up |
| wandering.js `WanderEngine._lead` | a watching tab takes the simulation lock from a background tab |
| wandering.js `WanderEngine._run` | live beats use a fresh away summary (not accumulated); background ticks accumulate `awaySummary` |
| wandering.js `WanderEngine.tick` | returns at once while `ZI.wanderMounted` (the screen drives `liveStep` instead) |
| active.js `retreatWatching` | requires the real screen element laid out and the page visible (DOM read) |
| screens-v3.jsx `syncWanderState` (~1692) | **screen-only gameplay write**: `hp`, `kills`, `xp`, `mats`, `healsUsed`, `moveSpeed`, `healPct` pushed into the run. `moveSpeed` comes from gear speed, buffs and stims; `healPct` from First Aid level. Never written while unwatched (defaults 3 and 25) |
| screens-v3.jsx `setWanderScroll` (two sites) | screen-only write of the run's distance |
| screens-v3.jsx `ZI.addBuff` (four sites), `ZI.setPolicy`, `ZI.drainWanderLog` | screen-only actions |
| screens-v3.jsx stim timer (`now0 < stimUntil`) | screen-only, real time, feeds `moveSpeed` |
Empirically (feasibility review): before the first HOLD, watched and unwatched run state is identical.

### H1 status (Oct 10)
- All 14 existing suites plus `tests/sim-clock-rng.test.js`: 434/434. `r1` ×20 frozen clock and ×5 with a 5 ms delay: check 15 passes in all 25 runs.
- Browser save isolation **PASSED** (Sam, Chrome, Oct 10) on the **local H1 build** at `http://127.0.0.1:8080`: `storage ok`, `shimActive true`, banner shown, `h1Build true`. Real-save fingerprint 1883847335 before and after 1–2 minutes of TEST SAVE play including Wandering (29 real keys, 29 game keys, both unchanged); test keys rose 11 → 24.
- **Still required before the Claude Design preview runs H1:** that preview (origin `https://019defa1-…claudeusercontent.com`) runs the pre-H1 build (`h1Build: false`, Oct 10). Before the real-game preview runs any H1 build: record the real-save fingerprint in the TEST SAVE preview frame, sync, confirm `h1Build: true` and `shimActive: true`, and confirm the fingerprint is unchanged before and after TEST SAVE play.

## FX1 implementation facts (Oct 10)
- HP floor: the fight write in `WanderSim.resolveEncounter` stores `Math.max(1, res.hpLeft)`. Every survivor HP write now stores ≥ 1 (fight, policy hit, venture, Fort attack, Traversal loot, heal, revive, rest).
- One Downed path: `ZI.WanderSim._downed(state, rng, away)` in `game/wandering.js` — heal (base → med kit) → revive consumable → `ZI.forcedRetreat(state, 'downed', rng)`; records the retreat on `away` when given (null for a venture chosen on screen). Callers: the fight path (when the fight isn't won **or** leaves HP at 1), the policy-hit branch of `advance()` (HP brought to 1), and the failed-venture branch of `ZI.resolvePrompt` (HP brought to 1; the ambush is skipped after a Forced Retreat).
- Not callers (U25, U26): `ZI.fortAttack` (`game/fort.js`) and the Traversal loot failure (`screens-v3.jsx` ~886). Both floor HP at 1 and never Down. Neither file changed.
- Policy-hit Downed is logged as a `policy` event (fields `downed`, `fr`) so the existing screen shows it; no screen change.
- `restStartHp` after a Downed Forced Retreat is 1 (rest from 1 to 80 HP = 948,000 ms at 5 HP/min).
- Tests: new `tests/fx1-downed-hp.test.js` (12 checks). Authorized edits: `sim-clock-rng` test 11 HP bound 1–100 (DH1 INFO note removed); `r1` check 28 gained a third scenario (load 116%, heals 2, seed 31).
- No save keys, migrations or save version changed.

## FX2 implementation facts (Oct 10)
- Per-return cap: `WanderEngine._run` computes `pending = min(offlineCapSec × 1000, newMs + _carryMs)` before processing. The new part (`min(pending, newMs)`) is passed to `advance()` as `dt`; the rest stays in `_carryMs`. Anything beyond the cap is discarded (U2). `_simNow` is seeded as `now − pending` (H1 A1a unchanged).
- Invariant: at the start of every engine run, waiting time (new + carried) ≤ 24 h. `_carryMs` and `lastTickAt` are used only in `game/wandering.js` (`_run`, `advance`); the screen writes `lastTickAt` once when a run restarts (`screens-v3.jsx` ~2502, unchanged).
- No new saved field (P1): discarded time is not stored. Side effect: `_carryMs` is now set before `advance()` runs, so it appears earlier in the saved run JSON (field order only; values identical).
- Tests: new `tests/fx2-return-cap.test.js` (8 checks; processed time measured by wrapping `advance()` and summing `_simNow` movement). Authorized edit: `sim-clock-rng` test 10c is now a PASS check (second-return backlog ≤ 24 h; was an INFO reading of 47.99 h).
- No save keys, migrations or save version changed.
