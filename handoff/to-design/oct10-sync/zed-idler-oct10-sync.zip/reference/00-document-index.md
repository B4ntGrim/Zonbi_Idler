# Zed Idler — Document Index (Oct 10, merged)

Start here. This lists every design document, its folder and its status.
Rules for how design work is done: `CLAUDE_DESIGN_RULES.md` (project root).
Latest session handoff: `DESIGN_HANDOFF.md` (project root).
Code's list of deferred items: `PARKED.md` (project root). Kept by Code; separate from the parked design briefs below.

**Status key:** Current (in force) · Active slice (next to build) · Planning (not a build input) · `[PARKED]` (designed, not scheduled) · Archived (finished or retired)

---

## Current design — `reference/`

| File | What it is | Status |
|---|---|---|
| `wandering-tab-spec.md` (v2.1) | The master spec: policies, decay, factions, discovery prompts, stress, pockets, difficulty | Current. Source of truth for game rules. §13.8 updated for U5/U6 (Oct 10). Tutorial and Scenario B decisions of Oct 10 live in the Elder Jester and Scenario B records until folded in |
| `wandering-fort-scene.md` | The first Fort: gate, guard, quest Fallow Ground | Current. Sections 10 and 11 are current; Sections 2-9 are partly superseded |
| `tutorial-first-session-spec.md` | The first 20-30 minutes | Current. **Superseded in part** by `elder-jester-concept.md` (§3.2 starter kit, Beat 3, Beat 5, tutorial end) and `scenario-b-and-first-downed-oct10.md` (first Downed beat) until the tutorial batch folds them in |
| `poi-framework-v1-brief.md` | Shared POI rules (placement, discovery, saving, revisits), proven with Water | **Active slice. Blocked** until R1 is confirmed CLOSED and FX1 is CLOSED (U7: the drain is fixed by FX1) |
| `sim-harness-v1-brief.md` | Simulation and test harness: one clock, seeded rolls, policy × difficulty runs, gates 1 and 3 | H1 **CLOSED** (Oct 10). H2 decided in outline; starts after H1, FX1, FX2 and CB1 are CLOSED (U3; CB1 added Oct 10). 80 runs (J7). D11 superseded by U19 until the H2 draft |
| `h1-findings-decisions-oct10.md` | Decisions on gameplay issues found during H1 (Q1–Q6) and open questions for Code (TQ1–TQ10) | Current. Q1, Q2, Q4, Q5, Q6 `[DECIDED Oct 10]`; Q3 pending verification |
| `gameplay-fix-batches-proposal.md` | Where Q1–Q6 were recorded, spec conflicts, batch order FX1–FX4, questions for Code and Sam, H2 scenario matrix | `[PROPOSED]` planning record. Batch order: FX1 → FX2 → CB1 → FX3 → FX4 → H2. FX1 and FX2 sections superseded by their slice briefs |
| `r1-fx1-readiness-review.md` | Code's read-only review: R1 closure items, DH1 vs the HP drain bug, FX1 scope and tests | Current (Code, Oct 10). Input for FX1; not a batch. Its §3 "separate defects" finding is superseded by U7 |
| `fx1-hp-floor-slice.md` | FX1: HP floor 1; reaching 1 HP from any source Downs | **CLOSED Oct 10.** Batch archived as `archive/fx1-batch.md` |
| `fx2-per-return-cap-slice.md` | FX2: 24 h per-return cap including carry; excess discarded | **CLOSED Oct 10.** Batch archived as `archive/fx2-batch.md` |
| `starter-weapons-cb1-slice.md` | CB1: balanced starter weapons (Nail Bat heavy swing, Iron Knuckles stagger, Pocket Knife escape + loot), three new weapon fields, simulated values, draft batch | Slice drafted; awaiting Sam's lock. Runs after FX2 |
| `elder-jester-concept.md` | The Elder Jester: companion and sole source of the starter kit; starter weapon pick; quest med kit (locked); tutorial ends at the Fort's approach; skip warning; wake-up first meeting | Current `[CONCEPT]` with decided parts. Supersedes tutorial §3.2/Beats 3 and 5, and Scenario B's U8/U10 |
| `scenario-b-and-first-downed-oct10.md` | Scenario B record, code findings F1–F3, the first Downed beat (U9, U11–U13) | Current; partly superseded by `elder-jester-concept.md` |

## Planning — `reference/` (not a build input; do not give to Code)

| File | What it is |
|---|---|
| `zed-idler-design-lead-brief.md` | Business model, roadmap, release readiness, working agreements |
| `wandering-design-audit.md` | What was fixed and the decisions still open |
| `00-document-index.md` | This file |

## Parked — `reference/parked/`

| File | What it is | Parked until |
|---|---|---|
| `wandering-church-scene.md` | The Church: optional specialized comfort. Repeatable POI `[DECIDED Oct 9]`; never gates core comfort `[DECIDED Oct 3]`; shop and blessing output `[PARKED]` | POI Framework v1 is complete and the comfort-items system exists |
| `wandering-workshop-scene.md` | The Workshop: field repair and salvage. Normal POI placement `[DECIDED Oct 9]` | POI Framework v1 is complete |
| `wandering-horde-ground-scene.md` | The Horde Ground: wave combat for RMAT | POI Framework v1 is complete and the Horde Ground is scheduled |
| `faction-quests-and-poi-density.md` | Faction quests, travel altercations, per-grid POI density | POI Framework v1 and a faction quest system |
| `headshots-concept.md` | Headshots as killing-blow crits | Gear/weapon metrics are defined |
| `design-notes.js` | Old design tables removed from the game code. Predates spec v2.0; not authoritative | Ideas only; check against the spec before reusing |

## Archived — `reference/archive/`

| File | Why |
|---|---|
| `batch2-handoff.md` | Batch 2 finished |
| `batch3b-brief.md` | Batch 3B finished |
| `r1-brief.md` | R1 built and tested (42/42). Confirm CLOSED with Code |
| `h1-batch.md` | H1 batch contract, CLOSED Oct 10 (Claude Design's corrected copy) |
| `fx1-batch.md` | FX1 batch contract, CLOSED Oct 10 |
| `fx2-batch.md` | FX2 batch contract, CLOSED Oct 10 |
| `h1-batch-working-copy.md` | Code's root working copy of the H1 contract ("Resumable, Oct 9" status), preserved at the Oct 10 sync |
| `H1_CLOSURE_FOR_CLAUDE_DESIGN.md` | Code's H1 documentation closure package (Oct 10), preserved at the Oct 10 sync |
| `h1-acceptance-report.md` | Code's H1 acceptance report (Oct 10). `H1_ACCEPTANCE_REPORT.md` is a byte-identical duplicate |
| `wandering-tab-spec-pre-merge-oct9.md` | Spec copy replaced Oct 9 by the merged v2.1 |
| `wandering-church-scene-pre-disposition-oct9.md` | Church brief before the Oct 3 disposition was integrated (Oct 9) |
| `archive/design-handoff-oct9.md`, `archive/design-handoff-oct10-am.md` | Earlier handoffs (root `archive/`) |

## Retired names (do not use)

| Name | Replaced by |
|---|---|
| `zombie-idler-wandering-spec.md` | `wandering-tab-spec.md` (its content was merged into v2.1 on Oct 9; the copy in `uploads/` is no longer current) |
| `zombie-idler-wandering-brainstorm.md` | `wandering-tab-spec.md` |
| `mystic-jester-concept.md` / "Mystic Jester" | `elder-jester-concept.md` / the Elder Jester (Oct 10) |

---

## Decisions log (recent)

| Date | Decision | Recorded in |
|---|---|---|
| Oct 10 | FX2 CLOSED (per-return 24 h cap including carried time) | `reference/archive/fx2-batch.md`; `handoff/to-design/FX2_COMPLETION_REPORT.md` |
| Oct 10 | FX1 CLOSED (V3 passed); FX2 active | `reference/archive/fx1-batch.md`; `handoff/to-design/FX1_COMPLETION_REPORT.md` |
| Oct 10 | U27 order of authority: player retreat setting < Downed at 1 HP and the fixed resume gate. FX1 implemented; V3 pending | `fx1-hp-floor-slice.md` §2 |
| Oct 10 | U25 Fort scene exempt from U5 (cannot be Downed there); U26 Traversal loot exempt; U5 applies to damage inside a Wandering run | `fx1-hp-floor-slice.md` §2; spec §13.8; `CURRENT_BATCH.md` |
| Oct 10 | J1 Elder Jester. J6 first meeting = wake-up scene at his camp after being Downed; first in-game Downed = second appearance. J7 H2 = 80 runs, B per starter weapon. U20 starter weapon identities. U21 first med kit = locked quest item. U22 pouch and scout kit from the Jester. U23 skippers meet him later without the kit. U24 `[CONCEPT]` guardrail, not a rescuer | `elder-jester-concept.md` §7; `starter-weapons-cb1-slice.md` |
| Oct 10 | U14 refined (skip warning), U15 `[CONCEPT]` Jester companion, U16 starter kit only from the Jester, U17 starter pick of three, U18 tutorial ends at the Fort's approach, U19 Scenario A = skipped, B = completed | `elder-jester-concept.md` §2 |
| Oct 10 | U8 Scenario B = prepared survivor; U9 `[CONCEPT]` hard-at-first message at the first Downed; U11 `[CONCEPT]` narrated finds point to tabs; U12 first Downed keeps the whole haul; U13 splash shows even if the tutorial was skipped | `scenario-b-and-first-downed-oct10.md` |
| Oct 10 | FX2 locked with P1 and P2 | `fx2-per-return-cap-slice.md` §4.1 |
| Oct 10 | HP floor 1 in all states (Q1); 24 h cap counts carried time per return (Q2); buffs evaluated at simulation time (Q4); `moveSpeed`/`healPct` move to shared rules (Q5). Each a separate batch, not H1 | Spec §13.8, §9, §3.2; `h1-findings-decisions-oct10.md` §1 |
| Oct 10 | H2 runs two scenarios: authentic new save, and a simulation-only starter-carrier fixture (Q6) | Sim-harness brief §6 D4, D5, D10, D11 |
| Oct 10 | U5 any damage source reaching 1 HP Downs (supersedes U1 trigger wording) · U6 Downing hit logs full damage · U7 HP drain bug = DH1, fixed by FX1 · FX1 locked | `fx1-hp-floor-slice.md` §2; spec §13.8 |
| Oct 10 | U1–U4 decided: Downed keeps HP at 1; strict 24 h per-return cap including carried time; H2 waits for H1, FX1, FX2; Scenario B uses the Belt Pouch | `sim-harness-v1-brief.md` |
| Oct 10 | H1 (one clock, seeded rolls) CLOSED; browser isolation passed on the local build | `archive/h1-acceptance-report.md` |
| Oct 10 | XP decay floor (Q3) pending Code's verification; no fix authorized | Spec §3.4 note |
| Oct 9 | The Church is a repeatable POI type | POI framework §3; Church brief §2 |
| Oct 9 | The Workshop uses normal POI placement | POI framework §3; Workshop brief §2 |
| Oct 9 | The world is not a fixed size; every POI type places per grid | POI framework §2; faction quests brief §3 |
| Oct 9 | Church disposition integrated: core comfort independent of the Church; shop and trade `[PARKED]`; blessing output `[PARKED]`; Remove stress `[PROPOSED]` | Church brief §0, §3-6, §10 |
| Oct 9 | Spec v2.1: two diverged copies merged (batch 1A-3B decisions + Oct 1 story-item and familiarity rules) | `wandering-tab-spec.md` |
