# Headshots — concept

Status: [DECIDED concept, PARKED numbers]. Not in any current batch. Do not implement.

[DECIDED] The killing blow is the last strike the character makes on an enemy to kill it. A headshot is a critical hit on the killing blow. It uses the existing critical-hit roll; there is no separate headshot roll. It resolves automatically inside normal combat, using the canonical seeded RNG, so live and offline results match.

## Effect of a headshot
A headshot does not shorten the fight or change damage taken; it lands on the strike that already kills. Its value is a bonus on top of the kill:
- Gear takes less wear for that fight.
- [DECIDED] The kill is quieter: a headshot reduces the stress gained from that encounter. It does not change follow-up encounter rates. The size of the reduction is [PARKED] with the gear/weapon metrics.

## What sets the chance
The headshot chance is the crit chance on the killing blow, modified by:
- Skill: crit chance grows with the relevant combat skill.
- Weapon: aimed weapons (blades, firearms) raise killing-blow crit chance; blunt weapons raise it less.
- Zombie type: armored or helmeted types lower it; some types (e.g. crawlers) raise it. Each type's modifier lives in the canonical enemy data table.

## Codex
- Each entry shows the player's headshot figure for that type (killing-blow crits per zombie type), alongside encounters and kills.
- This needs a per-type crit counter, which does not exist yet.
- The headshot figure appears only once that counter is implemented. Until then the Codex shows encounters and kills only.

## Sunken Blade
- The Blade's signature special is "Godly Strike": a chance to instantly kill a target. It is separate from headshots.

## Parked
- [PARKED] All numbers (killing-blow crit chance, skill scaling, weapon and zombie modifiers, wear/stress reductions, Godly Strike chance) wait for the gear/weapon metrics.
