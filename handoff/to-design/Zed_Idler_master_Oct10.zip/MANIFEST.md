# Master document set — from Claude Code (Oct 10)

These are the **master copies** of every design and state document in `E:\Zed_Idler`, after both Claude Design exports were integrated and verified byte for byte. Subfolders mirror the project layout. Use this set to bring the Claude Design project into line.

**Ownership is unchanged.** Claude Design owns the briefs, specs, index and handoff. Code owns `CODE_STATE.md` and `PARKED.md`. Code changed no design wording. Every Design file here is exactly as Claude Design exported it.

## Files (MD5, first 12 characters)

```
2b803bcda1bf  CLAUDE_DESIGN_RULES.md
a6bcea99ed13  CODE_STATE.md
555f9d68e681  DESIGN_HANDOFF.md
16b59d117d9f  PARKED.md
39635aea8523  archive/design-handoff-oct9.md
46470238ccdb  reference/00-document-index.md
adfea58b576b  reference/archive/batch2-handoff.md
a19a8178c394  reference/archive/batch3b-brief.md
b18d2e0444bb  reference/archive/h1-acceptance-report.md
d8f6feb76a27  reference/archive/h1-batch.md
3c63b4edeba1  reference/archive/r1-brief.md
4cad53946c78  reference/archive/wandering-church-scene-pre-disposition-oct9.md
c2f963d91ec8  reference/archive/wandering-tab-spec-pre-merge-oct9.md
8940a8219fe6  reference/gameplay-fix-batches-proposal.md
1106f8eca2a6  reference/h1-findings-decisions-oct10.md
c30795e31b12  reference/parked/design-notes.js
7bcaabdd1b84  reference/parked/faction-quests-and-poi-density.md
b0132b988e6b  reference/parked/headshots-concept.md
2582ba949a8b  reference/parked/wandering-church-scene.md
c7fa552716b3  reference/parked/wandering-horde-ground-scene.md
e009d613f82e  reference/parked/wandering-workshop-scene.md
ce1dcb668e72  reference/poi-framework-v1-brief.md
f437bcb9ccca  reference/r1-fx1-readiness-review.md
5dd9e567fc7d  reference/sim-harness-v1-brief.md
ff5edeb7cf32  reference/tutorial-first-session-spec.md
090e222651a3  reference/wandering-design-audit.md
87457b2d1069  reference/wandering-fort-scene.md
94c773fa6fc9  reference/wandering-tab-spec.md
b69a6500c98b  reference/zed-idler-design-lead-brief.md
```

**Not included:** game code, tests, `DEVELOPMENT_STATUS.md` (see the message, item 4), and superseded files still at the local root (`CURRENT_BATCH.md`, `H1_CLOSURE_FOR_CLAUDE_DESIGN.md`, `reference/archive/H1_ACCEPTANCE_REPORT.md`). These stay only until deletion is enabled.
