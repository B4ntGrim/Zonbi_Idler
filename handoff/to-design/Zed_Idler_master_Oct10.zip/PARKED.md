# Zed Idler — Parked Design Items

Items deliberately deferred from a batch. Each row names where it came from
and which future slice owns it. Remove a row only when its slice decides it.

| Item | Source | Destination slice | Notes |
|---|---|---|---|
| Automatic withdrawal when overloaded | 3A | Retreat Rules | Built in R1 (load rule, 115% default) — confirm and remove |
| "Pack heavy: bank and return?" prompt for an attending player | 3A | Retreat Rules | Built in R1 (HOLD prompt, 20 s, watching only) — confirm and remove |
| Overnight overloaded run keeps fighting at ×1.15 stress and leaves loot behind | 3A | Retreat Rules | Addressed in R1 (r1 check 27: withdraws at 115%, banks, redeploys) — confirm and remove |
| Return-resource reserve | 3A | Retreat Rules | |
| Voluntary Stress withdrawal may create more recovery downtime than Breaking; compare safe-path vs failure-path costs during R1 tuning so intentional Breaking does not become the optimal strategy | R1 | Retreat Rules (tuning) | Balance item, not an R1 requirement. Stress 85 → <50 at −20/day ≈ 42 h; Breaking 60 → <50 at Bedroll ≈ 12 h |
| Repeated-Breaking and recovery spiral (resume checks HP, not stress) | 3B | Retreat Rules | Addressed in R1 (resume needs HP ≥ 80% AND stress < 50; r1 check 22) — confirm and remove |
| Dangerous / emergency Forced Retreat travel | 3B | Retreat Rules | Forced Retreat returns to Base immediately for now |
| Approximate value in the "left behind (too heavy)" report row | 3A | Retreat Rules | Count only for now; value becomes useful when the return report is redesigned |
| Dropping or abandoning haul in the field | 3A | Resource Priorities | |
| Resource Priorities and automatic item replacement | 3A | Resource Priorities | |
| Difficulty scaling of the overload multiplier | 3A | Difficulty | Uses Normal ×1.15 in every mode until then |
| Hard-mode minimum Forced Retreat loss floor | 3B | Difficulty | Zero loss at effective Scavenging 50+ is intended on Normal |
| Hard-mode carried-item loss on Forced Retreat | 3B | Difficulty | Spec 15.3 |
| Carrier recipes and final carrier balance | 3A | Carrying (later) | |
| Rig slot, Med/Stim quick slots | 3A | Carrying (later) | |
| Shop, Scheduling | 3A | Later | |
| Church, Workshop, Horde Ground and other points of interest | Oct 3 briefs | Later | Briefs exist; not scheduled |
| Water POI (fishing, 0–3 cells per grid) | Sam amendments | Water POI | Spec in `reference/poi-framework-v1-brief.md`. Blocked until R1 CLOSED and HP drain bug fixed |
| The Sunken Blade [PARKED]: one-time, world-unique Easter egg. After [PROPOSED: 50] water visits or fishing attempts, a pull triggers a terminal-style dialogue scene granting a unique rusted claymore that must be restored before use. Signature special: "Godly Strike", a chance to instantly kill a target (separate from headshots) | Water Amendment 2 | Water POI (post-v1) | Blocked on: basic fishing shipped AND gear/weapon metrics defined. Exact stats wait for gear/weapon metrics. OPEN: does the scene offer a real choice (draw it / leave it)? Not in Water v1 scope |
| Gear/weapon metrics | Water Amendment 2, Headshots concept | Gear/weapons (later) | Not yet defined. Blocks the Sunken Blade stats and headshot numbers |
| Headshot numbers — blocked on gear/weapon metrics | Headshots concept | Gear/weapons (later) | Headshot = crit on the killing blow (the last strike that kills the enemy), using the existing crit roll; no separate roll. Quiet-kill effect [DECIDED]: reduces stress gained from that encounter; no change to follow-up encounter rates. Parked: killing-blow crit chance, skill scaling, weapon and zombie modifiers, wear/stress reductions. Codex figure needs a per-type crit counter (not yet built). Concept in `reference/headshots-concept.md`. Not in any current batch |
| Bed tiers (Cot, Bunk, Proper bed) for Base rest stress recovery | R1 addendum | Base / Comfort (later) | `restBed()` always returns Bedroll (−20/day) until built; Base rest picks tiers up through `restBed()` with no R1 change. Spec 13.8 |
